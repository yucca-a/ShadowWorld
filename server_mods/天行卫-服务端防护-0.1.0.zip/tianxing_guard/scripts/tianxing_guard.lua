local M = {}
local reporter
function M.SetReporter(fn) reporter = fn end

local function Stats(inst)
    if not inst._tianxing_guard then
        inst._tianxing_guard = {inspect_corrections=0, rejected_map_actions=0}
    end
    return inst._tianxing_guard
end

local function RejectMap(inst, reason)
    local stats = Stats(inst)
    stats.rejected_map_actions = stats.rejected_map_actions + 1
    stats.last_map_reason = reason
    local now = GetTime()
    if reason ~= "player_busy" then
        if not stats.last_map_strike or now-stats.last_map_strike > 1.25 then stats.map_streak = 0 end
        stats.last_map_strike = now
        stats.map_streak = (stats.map_streak or 0) + 1
        if stats.map_streak >= 3 and reporter then reporter(inst, "recover") end
    end
    if not stats.next_log or now >= stats.next_log then
        stats.next_log = now + 10
        print("[TianxingGuard] Rejected map delivery:", inst.userid or "local", reason)
    end
end

function M.AttachLocomotor(self)
    if not self.ismastersim or self._tianxing_guard_attached then return end
    self._tianxing_guard_attached = true
    local PushAction = self.PushAction
    self.PushAction = function(loco, bufferedaction, ...)
        local pc = loco.inst.components.playercontroller
        if bufferedaction and bufferedaction.action == ACTIONS.LOOKAT and pc and
            pc.ismastersim and pc.handler == nil and pc.remote_vector and
            (pc.remote_vector.y == 3 or pc.remote_vector.y == 4) then
            -- PushAction calls OnRemoteBufferedAction before performing LOOKAT.
            -- That tiny position correction must not become a movement primitive.
            -- y=5 is the native post-action marker; it skips only the snap, while
            -- retaining the original LOOKAT action, controller logic and RPC checks.
            pc.remote_vector.y = 5
            local stats = Stats(loco.inst)
            stats.inspect_corrections = stats.inspect_corrections + 1
            local tick, now = GetTick(), GetTime()
            if stats.inspect_tick ~= tick then
                stats.inspect_tick, stats.inspect_in_tick = tick, 0
            end
            stats.inspect_in_tick = stats.inspect_in_tick + 1
            if stats.inspect_in_tick >= 3 and stats.flagged_tick ~= tick then
                stats.flagged_tick = tick
                if not stats.speed_window or now-stats.speed_window >= 1 then
                    stats.speed_window, stats.speed_frames = now, 0
                end
                stats.speed_frames = stats.speed_frames + 1
                if stats.speed_frames >= 8 and reporter then reporter(loco.inst, "speed") end
            end
        end
        return PushAction(loco, bufferedaction, ...)
    end
end

function M.AttachController(self)
    if not self.ismastersim or self._tianxing_guard_attached then return end
    self._tianxing_guard_attached = true
    local OnMapAction = self.OnMapAction
    self.OnMapAction = function(pc, actioncode, position, target, mod_name, ...)
        if mod_name == nil and actioncode == ACTIONS.MAPDELIVER_MAP.code then
            -- Reuse the native component and bufferedmapaction authorization.
            -- Validate before the action reaches locomotor/stategraph: rejecting
            -- it inside ACTIONS.fn would already be too late to stop recovery.
            local delivery = target and target:IsValid() and target.components and target.components.mapdeliverable
            local pending = delivery and delivery.bufferedmapaction
            if not delivery then
                RejectMap(pc.inst, "invalid_delivery_target")
                return
            elseif pc:IsBusy() then
                RejectMap(pc.inst, "player_busy")
                return
            elseif not pending or not pending:IsValid() or
                pending:GetAction() ~= ACTIONS.MAPDELIVER_MAP or not pending:IsDoer(pc.inst) then
                RejectMap(pc.inst, "missing_or_foreign_map_action")
                return
            end
        end
        return OnMapAction(pc, actioncode, position, target, mod_name, ...)
    end
end

return M
