local M = {}
local QUIET_TIME = 1.25
local LABELS = {
    speed="快速移动辅助（重复移动预测／观察校正）",
    recover="自动解控辅助（重复伪造地图投递）",
}

function M.New(options)
    options = options or {}
    local sessions = setmetatable({}, {__mode="k"})
    local function Cancel(session)
        for _, task in ipairs(session.tasks) do task:Cancel() end
        if session.cleanup then session.cleanup:Cancel() end
    end
    local function Describe(session)
        local names = {}
        for _, kind in ipairs({"speed", "recover"}) do
            if session.kinds[kind] then names[#names+1] = LABELS[kind] end
        end
        return table.concat(names, "、")
    end
    local function Say(inst, session, remaining)
        if not inst:IsValid() or sessions[inst] ~= session then return end
        local name = tostring(inst.name or inst.userid or "未知玩家"):gsub("[%c]", " ")
        local suffix = options.auto_kick ~= false and
            "若持续异常将被移出；倒计时" or "自动踢出已关闭；观察倒计时"
        options.announce("【天行卫】" .. name .. "行为异常：触发" .. Describe(session) ..
            "检测。" .. suffix .. remaining .. "秒。")
    end
    local function CleanupLater(inst, session)
        session.cleanup = inst:DoTaskInTime(QUIET_TIME, function()
            if sessions[inst] ~= session then return end
            if not inst:IsValid() or GetTime()-session.last >= QUIET_TIME then
                sessions[inst] = nil
            else
                CleanupLater(inst, session)
            end
        end)
    end
    local api = {}
    function api.Report(inst, kind)
        if not LABELS[kind] or not inst:IsValid() or not inst.userid then return end
        local now = GetTime()
        local session = sessions[inst]
        if session and session.kicked then return end
        if session and now-session.last > QUIET_TIME then
            Cancel(session)
            sessions[inst] = nil
            session = nil
        end
        if not session then
            session = {started=now, deadline=now+5, last=now, kinds={[kind]=true}, tasks={}}
            sessions[inst] = session
            Say(inst, session, 5)
            for second=1,4 do
                local remaining = 5-second
                session.tasks[#session.tasks+1] = inst:DoTaskInTime(second, function()
                    Say(inst, session, remaining)
                end)
            end
            session.tasks[#session.tasks+1] = inst:DoTaskInTime(5, function()
                -- Timers never kick using old evidence. A new violation after
                -- this deadline is required, so stopping at 4.99s is sufficient.
                CleanupLater(inst, session)
            end)
        else
            session.last = now
            session.kinds[kind] = true
            if now >= session.deadline and options.auto_kick ~= false then
                session.kicked = true
                Cancel(session)
                options.kick(inst, Describe(session))
            end
        end
    end
    return api
end

return M
