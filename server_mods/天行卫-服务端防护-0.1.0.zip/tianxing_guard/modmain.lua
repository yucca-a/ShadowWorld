local Guard = require("tianxing_guard")
local Watch = require("tianxing_guard_watch")
local G = GLOBAL
-- Use native server announcements; clients do not need the mod.
local watch = Watch.New({
    auto_kick = GetModConfigData("auto_kick") ~= false,
    announce = function(message)
        print("[TianxingGuard] Warning:", message)
        G.TheNet:Announce(message)
    end,
    kick = function(inst, reason)
        print("[TianxingGuard] Kick:", inst.userid, reason)
        G.TheNet:Kick(G.UserToClientID and G.UserToClientID(inst.userid) or inst.userid)
    end,
})
Guard.SetReporter(watch.Report)
AddComponentPostInit("locomotor", Guard.AttachLocomotor)
AddComponentPostInit("playercontroller", Guard.AttachController)
