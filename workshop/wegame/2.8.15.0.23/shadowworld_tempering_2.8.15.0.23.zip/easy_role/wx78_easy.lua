local hardmode = TUNING.hardmode2hm and GetModConfigData("role_nerf")
local inital_maxlevel = TUNING.WX78_MAXCHARGELEVEL_SKILL
local UpvalueHacker = require("upvaluehacker2hm")
-- WX-78拆电路板不消耗耐久不掉电力
if GetModConfigData("WX-78 Safe Remove Module") then
    local bodys = {
        "wx78_backupbody",
        "wx78_possessedbody",
        "wx78"
    }

    -- 拆电路板不消耗电力
    for i, prefab in pairs(bodys) do
        AddPrefabPostInit(prefab, function(inst)
            if not TheWorld.ismastersim then return end
            inst:DoTaskInTime(0, function()
                if inst.components.upgrademoduleowner and inst.components.upgrademoduleowner.ononemodulepopped then
                    local oldononemodulepopped = inst.components.upgrademoduleowner.ononemodulepopped
                    inst.components.upgrademoduleowner.ononemodulepopped = function(inst, moduleent, ...)
                        if not inst.nochargereduce2hm then inst.nochargereduce2hm = moduleent end
                        oldononemodulepopped(inst, moduleent, ...)
                        inst.nochargereduce2hm = nil
                    end
                end
            end)
        end)
    end

    AddComponentPostInit("upgrademoduleowner", function(self)
        local oldDoDeltaCharge = self.DoDeltaCharge
        self.DoDeltaCharge = function(self, n, ...)
            if hardmode and self.inst.nochargereduce2hm and self.inst.nochargereduce2hm ~= true and self.inst.nochargereduce2hm.level2hm then
                local moduleslotcount = self.inst.nochargereduce2hm.components.upgrademodule:GetSlots()
                local charge_cost = -moduleslotcount
                local skilltreeupdater = self.inst.components.skilltreeupdater
                if skilltreeupdater and skilltreeupdater:IsActivated("wx78_circuitry_bettercharge") then
                    charge_cost = math.min(charge_cost + TUNING.SKILLS.WX78.SAVE_CHARGE_ON_UNPLUG, -1)
                end
                n = charge_cost / math.floor(self.max_charge / moduleslotcount)  * (self.inst.nochargereduce2hm.level2hm:value() - 1)
            elseif (not hardmode and self.inst.nochargereduce2hm) or self.inst.nochargereduce2hm == true then
                n = 0
            end
            return oldDoDeltaCharge(self, n, ...)
        end
    end)

    ACTIONS.REMOVEMODULES.fn = function(act)
        if (act.invobject ~= nil and act.invobject.components.upgrademoduleremover ~= nil)
                and (act.doer ~= nil and act.doer.components.upgrademoduleowner ~= nil) then
            if act.doer.components.upgrademoduleowner:NumModules() > 0 then
                return true
            else
                return false, "NO_MODULES"
            end
        end

        return false
    end

    local module_definitions = require("wx78_moduledefs").module_definitions
    -- for _, def in ipairs(module_definitions) do
    --     AddPrefabPostInit("wx78module_" .. def.name, function(inst)
    --         if not TheWorld.ismastersim then return end
            -- if inst.components.finiteuses and inst.components.finiteuses.Use then
            --     local oldfn = inst.components.finiteuses.Use
            --     inst.components.finiteuses.Use = function(self, ...)
            --         if TUNING.saferemoveupgrademodule2hm then return end
            --         oldfn(self, ...)
            --     end
            -- end
            -- if inst.components.upgrademodule then
            --     local oldfn = inst.components.upgrademodule.onremovedfromownerfn
            --     inst.components.upgrademodule.onremovedfromownerfn = function(self, ...)
            --         TUNING.saferemoveupgrademodule2hm = true
            --         if oldfn then oldfn(self, ...) end
            --         TUNING.saferemoveupgrademodule2hm = nil
            --     end
            -- end
            -- 2025.10.13 melon:电路死亡不掉落
            -- if inst.components.inventoryitem then
            --     inst.components.inventoryitem.keepondeath = true -- 死亡不掉落
            --     inst.components.inventoryitem.keepondrown = true -- 溺水不掉落
            -- end
    --     end)
    -- end
    -- 2025.10.13 melon:电路提取器死亡不掉落
    -- AddPrefabPostInit("wx78_moduleremover", function(inst)
    --     if not TheWorld.ismastersim then return end
    --     if inst.components.inventoryitem then
    --         inst.components.inventoryitem.keepondeath = true -- 死亡不掉落
    --         inst.components.inventoryitem.keepondrown = true -- 溺水不掉落
    --     end
    -- end)
    -- 2025.10.13 melon:无电路、电不满时右键扣5血回1格电 
    -- local _REMOVEMODULES_FAIL_fn = ACTIONS.REMOVEMODULES_FAIL.fn
    -- ACTIONS.REMOVEMODULES_FAIL.fn = function(act)
    --     if not act.doer.components.upgrademoduleowner:ChargeIsMaxed() then
    --         act.doer.components.upgrademoduleowner:AddCharge(1)
    --         if act.doer.components.health then act.doer.components.health:DoDelta(-5) end
    --     end
    --     return _REMOVEMODULES_FAIL_fn(act)
    -- end
    -- 2025.10.13 melon:生物扫描分析仪wx78_scanner跟随下地
    AddPrefabPostInit("wx78", function(inst)
        if not TheWorld.ismastersim then return end
        local _OnDespawn = inst.OnDespawn
		inst.wx78_scanner_save2hm = nil
		inst.OnDespawn = function(inst, migrationdata, ...) -- 随从下洞以及带下线代码
			for k, v in pairs(inst.components.leader.followers) do
				if k.prefab == "wx78_scanner" then 
					inst.wx78_scanner_save2hm = k:GetSaveRecord()
					-- remove followers
					k:AddTag("notarget")
					k:AddTag("NOCLICK")
					k.persists = false
					k:DoTaskInTime(0.1, function(k)
						local fx = SpawnPrefab("spawn_fx_small")
						fx.Transform:SetPosition(k.Transform:GetWorldPosition())
						if not k.components.colourtweener then
							k:AddComponent("colourtweener")
						end
						k.components.colourtweener:StartTween({ 0, 0, 0, 1 }, 13 * FRAMES, k.Remove)
					end)
                    -- break -- 只1个
				end
			end
			return _OnDespawn(inst, migrationdata, ...)
		end
		local _OnSave = inst.OnSave
		inst.OnSave = function(inst, data, ...)
			data.wx78_scanner_save2hm = inst.wx78_scanner_save2hm
			if _OnSave ~= nil then return _OnSave(inst, data, ...) end
		end
		local _OnLoad = inst.OnLoad
		inst.OnLoad = function(inst, data, ...)
			if data and data.wx78_scanner_save2hm then
                inst:DoTaskInTime(0.1, function(inst)
                    local follower = SpawnSaveRecord(data.wx78_scanner_save2hm)
                    inst.components.leader:AddFollower(follower)
                    follower:DoTaskInTime(0, function(follower)
                        if inst:IsValid() and not follower:IsNear(inst, 8) then
                            follower.Transform:SetPosition(inst.Transform:GetWorldPosition())
                            follower.sg:GoToState("idle")
                        end
                    end)
                    local fx = SpawnPrefab("spawn_fx_small")
                    fx.Transform:SetPosition(follower.Transform:GetWorldPosition())
                end)
			end
			if _OnLoad ~= nil then return _OnLoad(inst, data, ...) end
		end
    end)
end

-- WX-78同种电路板融合升级
if GetModConfigData("WX-78 Integrated Upgrade Module Level") then
    local blacklist = {
        -- "wx78module_stacksize"
    }

    -- 移速数值扩展
    local index = #TUNING.WX78_MOVESPEED_CHIPBOOSTS
    local diff = TUNING.WX78_MOVESPEED_CHIPBOOSTS[index] - TUNING.WX78_MOVESPEED_CHIPBOOSTS[index - 1]
    for i = index + 1, inital_maxlevel, 1 do
        TUNING.WX78_MOVESPEED_CHIPBOOSTS[i] = math.clamp(TUNING.WX78_MOVESPEED_CHIPBOOSTS[i - 1] + diff, 0, 10)
    end
    local function DisplayNameFn(inst)
        if inst.level2hm:value() ~= 1 then
            return inst.name .. " Lv" .. inst.level2hm:value()
        else
            return inst.name
        end
    end
    local function OnSave(inst, data)
        if inst.level2hm ~= nil then
            data.level = inst.level2hm:value()
        else
            data.level = 1
        end
    end
    local function OnLoad(inst, data) if data ~= nil then if data.level ~= nil then inst.level2hm:set(data.level) end end end
    local module_definitions = require("wx78_moduledefs").module_definitions
    local function itemtilefn(inst)
        local leveltext
        if inst.level2hm and inst.level2hm:value() >= 2 then leveltext = "Lv" .. inst.level2hm:value() end
        return "level2hmdirty", leveltext
    end
    for _, def in ipairs(module_definitions) do
        AddPrefabPostInit("wx78module_" .. def.name, function(inst)
            inst.repairmaterials2hm = {scandata = 1}
            inst.level2hm = net_smallbyte(inst.GUID, "module.level2hm", "level2hmdirty")
            inst.itemtilefn2hm = itemtilefn
            inst.displaynamefn = DisplayNameFn
            if not TheWorld.ismastersim then return end
            inst:DoTaskInTime(0.1, function(inst)
                if TUNING.DSTU and not inst.components.finiteuses and inst.components.fueled then
                    inst.repairmaterials2hm.scandata = 480 * 5
                end
            end)
            inst.level2hm:set(1)
            inst.OnSave = OnSave
            inst.OnLoad = OnLoad
            -- if not TUNING.DSTU then 
            inst:AddComponent("repairable2hm")
            -- end
            -- inst.components.repairable2hm.customrepair = onrepair
        end)
    end
    -- if TUNING.DSTU and FUELTYPE.CIRCUITBITS then
    --     AddPrefabPostInit("scandata", function(inst)
    --         if not TheWorld.ismastersim then return end
    --         inst:AddComponent("fuel")
    --         inst.components.fuel.fueltype = FUELTYPE.CIRCUITBITS
    --         inst.components.fuel.fuelvalue = 480 * 5
    --     end)
    -- end
    AddComponentPostInit("upgrademodule", function(self)
        local SetTarget = self.SetTarget
        self.SetTarget = function(self, target, isloading, ...)
            if self.inst.level2hm then
                self.target = target
                local level = self.inst.level2hm:value()
                for index = 1, level or 1 do
                    if index == 1 then
                        if self.onaddedtoownerfn ~= nil then self.onaddedtoownerfn(self.inst, target, isloading) end
                    else
                        self.tmp2hm = self.tmp2hm or {}
                        local tmpinst = self.tmp2hm[index - 1] or SpawnPrefab(self.inst.prefab)
                        if tmpinst and tmpinst:IsValid() then
                            self.tmp2hm[index - 1] = tmpinst
                            if self.onaddedtoownerfn ~= nil then self.onaddedtoownerfn(tmpinst, target, isloading) end
                            tmpinst.persists = false
                            self.inst:AddChild(tmpinst)
                            tmpinst:RemoveFromScene()
                            tmpinst.Transform:SetPosition(0, 0, 0)
                        end
                    end
                end
            else
                SetTarget(self, target, isloading, ...)
            end
        end
        local TryActivate = self.TryActivate
        self.TryActivate = function(self, isloading, ...)
            if not self.activated and self.inst.level2hm then
                self.activated = true
                local level = self.inst.level2hm:value()
                if self.onactivatedfn ~= nil then
                    for index = 1, level or 1 do
                        if index == 1 then
                            self.onactivatedfn(self.inst, self.target, isloading)
                        else
                            self.tmp2hm = self.tmp2hm or {}
                            local tmpinst = self.tmp2hm[index - 1] or SpawnPrefab(self.inst.prefab)
                            if tmpinst and tmpinst:IsValid() then
                                self.onactivatedfn(tmpinst, self.target, isloading)
                            end
                        end
                    end
                end
            else
                TryActivate(self, isloading, ...)
            end
        end
        local TryDeactivate = self.TryDeactivate
        self.TryDeactivate = function(self, ...)
            if self.activated and self.inst.level2hm then
                self.activated = false
                local level = self.inst.level2hm:value()
                if self.ondeactivatedfn ~= nil then
                    for index = level or 1, 1, -1 do
                        if index == 1 then
                            self.ondeactivatedfn(self.inst, self.target)
                        else
                            self.tmp2hm = self.tmp2hm or {}
                            local tmpinst = self.tmp2hm[index - 1]
                            if tmpinst and tmpinst:IsValid() then
                                self.ondeactivatedfn(tmpinst, self.target)
                            end
                        end
                    end
                end
            else
                TryDeactivate(self, ...)
            end
        end
        local oldRemoveFromOwner = self.RemoveFromOwner
        self.RemoveFromOwner = function(self, ...)
            if self.inst.level2hm then
                local level = self.inst.level2hm:value()
                for index = level or 1, 1, -1 do
                    if index == 1 then
                        if self.onremovedfromownerfn ~= nil then self.onremovedfromownerfn(self.inst, self.target) end
                    else
                        self.tmp2hm = self.tmp2hm or {}
                        local tmpinst = self.tmp2hm[index - 1]
                        if tmpinst and tmpinst:IsValid() then
                            if self.onremovedfromownerfn ~= nil then self.onremovedfromownerfn(tmpinst, self.target) end
                            self.tmp2hm[index - 1] = nil
                            tmpinst:Remove()
                        end
                    end
                end
            else
                oldRemoveFromOwner(self, ...)
            end
        end
    end)
    AddComponentPostInit("upgrademoduleowner", function(self)
        local oldCanUpgrade = self.CanUpgrade
        self.CanUpgrade = function(self, module_instance)
            if self._last_upgrade_time ~= nil then if (self._last_upgrade_time + self.upgrade_cooldown) > GetTime() then return false, "COOLDOWN" end end
            local slots = module_instance.components.upgrademodule.slots
            if module_instance.level2hm then
                local count = 0
                count = count + module_instance.level2hm:value()
                for bartype, modules in pairs(self.module_bars) do
                    for _, module in ipairs(modules) do
                        if module.prefab == module_instance.prefab and module.level2hm then count = count + module.level2hm:value() end
                    end
                end
                if self.max_charge / slots < count then return false, "NOTENOUGHSLOTS" end
            end
            return oldCanUpgrade(self, module_instance)
        end

        -- 升级插槽计数兼容
        self.GetModuleTypeCount = function(self, moduletype, ...)
            local count = 0
            local module_prefab = "wx78module_"..moduletype
            for bartype, modules in pairs(self.module_bars) do
                local remaining_charge = self.charge_level
                for _, moduleent in ipairs(modules) do
                    remaining_charge = remaining_charge - moduleent.components.upgrademodule.slots
                    if remaining_charge < 0 then
                        break
                    elseif moduleent.prefab == module_prefab and moduleent.level2hm then
                        count = count + moduleent.level2hm:value()
                    end
                end
            end
            return count
        end
        local oldGetAllModules = self.GetAllModules
        self.GetAllModules = function(self, ...)
            local modules = oldGetAllModules(self, ...)
            local _modules = modules
            if next(_modules) ~= nil then
                for _, ent in pairs(_modules) do
                    if ent and ent.components.upgrademodule and ent.components.upgrademodule.tmp2hm then
                        for i, v in pairs(ent.components.upgrademodule.tmp2hm) do
                            if v and v:IsValid() then table.insert(modules, v) end
                        end
                    end
                end
            end
            return modules
        end
    end)
    AddComponentAction("USEITEM", "upgrademodule", function(inst, doer, target, actions)
        if inst.prefab == target.prefab and not table.contains(blacklist,inst.prefab) and doer:HasTag("upgrademoduleowner") then table.insert(actions, ACTIONS.UPGRADE) end
    end)
    local maxmoduletext = TUNING.isCh2hm and "功率已到极限，这块电路已经满级了。" or
                             "Power at maximum. This circuit is fully upgraded."
    local sameleveltext = TUNING.isCh2hm and "两块同级电路会互相冲突，先升级其中一块。" or
                             "Two circuits of the same level conflict. Upgrade one of them first."
    local function SayModuleText(doer, text)
        if doer and doer.components.talker then doer.components.talker:Say(text) end
    end
    local oldUPGRADEfn = ACTIONS.UPGRADE.fn
    ACTIONS.UPGRADE.fn = function(act)
        if not (act.invobject and act.target and act.invobject.prefab == act.target.prefab and act.invobject.components.upgrademodule and
            act.target.components.upgrademodule and act.invobject.level2hm and act.target.level2hm) then
            return oldUPGRADEfn(act)
        end
        local invlevel = act.invobject.level2hm:value()
        local targetlevel = act.target.level2hm:value()
        local slots = act.invobject.components.upgrademodule.slots or 1
        local maxlevel = math.max(1, math.floor(inital_maxlevel / slots))
        local newlevel = invlevel + targetlevel

        if oldUPGRADEfn(act) then
            if act.target and act.target.level2hm and act.target.level2hm:value() > targetlevel and
                act.target.level2hm:value() >= maxlevel then
                SayModuleText(act.doer, maxmoduletext)
            end
            return true
        end
        if invlevel == targetlevel and newlevel > maxlevel then
            SayModuleText(act.doer, sameleveltext)
            return false
        end
        if newlevel <= maxlevel then
            act.target.level2hm:set(newlevel)
            if act.doer then
                local shinefx = SpawnPrefab("pocketwatch_warpback_fx")
                shinefx.AnimState:SetTime(10 * FRAMES)
                shinefx.entity:SetParent(act.doer.entity)
            end
            if act.target.components.finiteuses then act.target.components.finiteuses:SetUses(TUNING.WX78_MODULE_USES) end
            act.invobject:Remove()
            if newlevel >= maxlevel then
                SayModuleText(act.doer, maxmoduletext)
            end
            return true
        end
    end
    -- 升级插槽计数兼容
    local WX78ModuleDefinitionFile = require("wx78_moduledefs")
    local GetWX78ModuleByNetID = WX78ModuleDefinitionFile.GetModuleDefinitionFromNetID
    AddPrefabPostInit("wx78_classified", function(inst)
        if inst.GetModuleTypeCount then
            inst.GetModuleTypeCount = function(inst, module_name)
                local count = 0
                --
                for bartype, modules in pairs(inst.upgrademodulebars) do
                    local remaining_charge = inst:GetEnergyLevel()
                    for _, module_netvar in ipairs(modules) do
                        local module_definition = GetWX78ModuleByNetID(module_netvar:value())
                        if module_definition ~= nil then
                            remaining_charge = remaining_charge - module_definition.slots
                            if remaining_charge < 0 then
                                break
                            elseif module_definition.name == module_name and module_definition.level2hm then
                                count = count + module_definition.level2hm:value()
                            end
                        else
                            break
                        end
                    end
                end
                --
                return count
            end
        end
    end)
    -- 技能树效果兼容
    -- 豆增压电路护盾值修正
    for i, v in ipairs(module_definitions) do
        if v and v.name == "bee" then
            local firstfn = UpvalueHacker.GetUpvalue(v.activatefn, "bee_skill_activate")
            if firstfn then
                local oldfn = UpvalueHacker.GetUpvalue(v.activatefn, "bee_skill_activate", "bee_skill_updatemaxshield")
                if oldfn then
                    local newfn = function(inst, wx, ...)
                        oldfn(inst, wx, ...)
                        if wx.components.wx78_shield then
                            local maxshield = wx.components.wx78_shield:GetMax()
                            if type(maxshield) == "number" then wx.components.wx78_shield:SetMax(math.clamp(maxshield, 1, 60)) end
                        end
                    end
                    UpvalueHacker.SetUpvalue(v.activatefn, newfn, "bee_skill_activate", "bee_skill_updatemaxshield")
                    break
                end
            end
        end
    end
end

-- WX-78吃齿轮升级
if GetModConfigData("WX-78 Eat Gears InCrease Data") then
    local function OnLoad(inst, data)
        if data ~= nil then
            inst.gearslevel2hm = math.min(inst._gears_eaten or 0, 15)
            inst.components.health.maxhealth = inst.components.health.maxhealth + inst.gearslevel2hm * 5
            inst.components.sanity.max = inst.components.sanity.max + inst.gearslevel2hm * 5
            inst.components.hunger.max = inst.components.hunger.max + inst.gearslevel2hm * 5
            if data._wx78_health then inst.components.health:SetCurrentHealth(data._wx78_health) end
            if data._wx78_sanity then inst.components.sanity.current = data._wx78_sanity end
            if data._wx78_hunger then inst.components.hunger.current = data._wx78_hunger end
        end
    end
    local function OnEat(inst, data)
        if data.food ~= nil and data.food.components.edible ~= nil and data.food.components.edible.foodtype == FOODTYPE.GEARS and inst.gearslevel2hm < 15 then
            inst.gearslevel2hm = (inst.gearslevel2hm or 0) + 1
            inst.components.health.maxhealth = inst.components.health.maxhealth + 5
            inst.components.sanity.max = inst.components.sanity.max + 5
            inst.components.hunger.max = inst.components.hunger.max + 5
            inst.components.health:DoDelta(5)
            inst.components.sanity:DoDelta(5)
            inst.components.hunger:DoDelta(5)
        end
    end
    local function OnDeath(inst)
        inst.components.health.maxhealth = inst.components.health.maxhealth - inst.gearslevel2hm * 5
        inst.components.sanity.max = inst.components.sanity.max - inst.gearslevel2hm * 5
        inst.components.hunger.max = inst.components.hunger.max - inst.gearslevel2hm * 5
        inst.gearslevel2hm = 0
    end
    AddPrefabPostInit("wx78", function(inst)
        if not TheWorld.ismastersim then return end
        inst.gearslevel2hm = 0
        SetOnLoad(inst, OnLoad)
        inst:ListenForEvent("oneat", OnEat)
        inst:ListenForEvent("death", OnDeath)
    end)
end

--2025.11.2夜风wx-78芯片容器
-- WX-78右键自身打开芯片容器(只能储存芯片/电路板/生物数据/钳子)
if GetModConfigData("wx78_module_pack") then
    require("actions")
    ACTIONS.TOGGLEWXSHIELDING.priority = -1
    ACTIONS.TOGGLEWXSCREECH.priority = 0
    -- 给 WX-78 相关物品添加标签（用于容器过滤）
    local function AddToolboxItemTag(prefab)
        AddPrefabPostInit(prefab, function(inst)
            inst:AddTag("wx78_toolbox_item")
        end)
    end
    
    -- 添加标签到所有模块
    local module_definitions = require("wx78_moduledefs").module_definitions
    for _, def in ipairs(module_definitions) do
        AddToolboxItemTag("wx78module_" .. def.name)
    end
    
    -- 添加标签到其他物品
    local wx78_items = {"wx78_scanner", "scandata", "wx78_moduleremover"}
    for _, prefab in ipairs(wx78_items) do
        AddToolboxItemTag(prefab)
    end
    
    -- 定义虚拟芯片容器参数（使用标签过滤）
    local containers = require("containers")
    containers.params.wx78_toolbox = {
        widget = {
            slotpos = {},
            animbank = "ui_chest_3x3",
            animbuild = "ui_chest_3x3",
            pos = Vector3(0, 200, 0),
            side_align_tip = 160,
        },
        type = "chest",
        itemtestfn = function(container, item, slot)
            return item ~= nil and item:HasTag("wx78_toolbox_item")
        end,
    }
    
    -- 设置 9 格槽位位置 (3×3)
    for y = 0, 2 do
        for x = 0, 2 do
            table.insert(containers.params.wx78_toolbox.widget.slotpos, Vector3(80 * x - 80, 80 * y - 80, 0))
        end
    end
    
    -- 初始化虚拟芯片容器
    local function inittoolbox(inst)
        if inst.toolbox2hm and inst.toolbox2hm:IsValid() then return end
        
        local toolbox = SpawnPrefab("wx78_toolbox")
        if not (toolbox and toolbox:IsValid() and toolbox.components.container) then return end
        
        -- 恢复保存的容器数据
        if inst.components.persistent2hm and inst.components.persistent2hm.data.wx78_toolbox then
            toolbox.components.container.init2hm = true
            toolbox:SetPersistData(inst.components.persistent2hm.data.wx78_toolbox)
            toolbox.components.container.init2hm = nil
            inst.components.persistent2hm.data.wx78_toolbox = nil
        end
        
        -- 设置容器属性和关联关系
        toolbox:AddTag("dcs2hm")
        toolbox:AddTag("NOBLOCK")
        inst.toolbox2hm = toolbox
        toolbox.master2hm = inst
        toolbox.components.container.skipautoclose = true
        toolbox.components.container.usespecificslotsforitems = false
        toolbox.components.container.acceptsstacks = true
        toolbox.persists = false
        toolbox:Hide()
        inst:AddChild(toolbox)
    end
    
    -- OnSave 时序列化容器数据
    local function OnSave(inst, data)
        if inst.toolbox2hm and inst.toolbox2hm:IsValid() then
            local persistdata = inst.toolbox2hm:GetPersistData()
            if persistdata then
                data.wx78_toolbox = persistdata
            end
        end
    end
    
    AddPrefabPostInit("wx78", function(inst)
        if not TheWorld.ismastersim then return end
        
        -- 添加 persistent2hm 组件
        if not inst.components.persistent2hm then 
            inst:AddComponent("persistent2hm")
        end
        
        -- 注册 OnSave
        SetOnSave2hm(inst, OnSave)
        
        -- 延迟初始化容器
        inst:DoTaskInTime(0, inittoolbox)
    end)
    -- 添加右键自身打开/关闭芯片容器功能
    AddRightSelfAction("wx78", 2, "dolongaction", nil, function(act)
        if act.doer and act.doer.prefab == "wx78" then
            local toolbox = act.doer.toolbox2hm
            if toolbox and toolbox:IsValid() and toolbox.components.container and act.doer == toolbox.master2hm then
                if toolbox.components.container.openlist[act.doer] then
                    toolbox.components.container:Close(act.doer)
                else
                    toolbox.components.container:Open(act.doer)
                end
                return true
            else
                -- 容器不存在或无效，重新初始化
                act.doer:DoTaskInTime(0, inittoolbox)
                return false
            end
        end
    end, TUNING.isCh2hm and "芯片容器" or "Circuit Container", nil, nil, function(inst)
		if inst.components.playercontroller and inst.components.playercontroller:IsControlPressed(CONTROL_FORCE_STACK) then
			return true
		end
		return false
	end)
end  

--2025.11.28 YeFeng: 热能电路防水效果
-- 更新防水效果的函数
local function UpdateHeatWaterproof(wx)
    if not wx or not wx.components.moisture then return end
    -- 检查是否有激活的热能芯片
    local has_heat_module = false
    if wx.components.upgrademoduleowner then
        for bartype, modules in pairs(wx.components.upgrademoduleowner.module_bars) do
            for _, module in ipairs(modules) do
                if module and module.prefab == "wx78module_heat" and
                    module.components.upgrademodule and module.components.upgrademodule.activated then
                    has_heat_module = true
                    break
                end
            end
        end
    end
    -- 根据是否有热能芯片设置防水效果
    if has_heat_module then
        -- Hook DoDelta函数，完全阻止潮湿度增加
        if not wx.components.moisture._original_DoDelta_heat_waterproof then
            -- 保存原始DoDelta函数
            wx.components.moisture._original_DoDelta_heat_waterproof = wx.components.moisture.DoDelta
            -- 替换为新的DoDelta函数
            wx.components.moisture.DoDelta = function(self, delta, ...)
                -- 只允许负值（干燥），阻止正值（变湿）
                if delta and delta > 0 then
                    delta = 0
                end
                -- 调用原始函数
                if self._original_DoDelta_heat_waterproof then
                    return self._original_DoDelta_heat_waterproof(self, delta, ...)
                end
            end
        end

        -- 立即清除已有的潮湿度
        if wx.components.moisture:GetMoisture() > 0 then
            wx.components.moisture:DoDelta(-wx.components.moisture:GetMoisture())
        end

        wx.wx78_heat_waterproof_active = true
    else
        -- 移除防水效果，恢复原始DoDelta函数
        if wx.wx78_heat_waterproof_active and wx.components.moisture._original_DoDelta_heat_waterproof then
            wx.components.moisture.DoDelta = wx.components.moisture._original_DoDelta_heat_waterproof
            wx.components.moisture._original_DoDelta_heat_waterproof = nil
            wx.wx78_heat_waterproof_active = nil
        end
    end
end
-- Hook热能电路的激活和卸载
AddPrefabPostInit("wx78module_heat", function(inst)
    if not TheWorld.ismastersim then return end
    inst:DoTaskInTime(0, function(inst)
        if inst.components.upgrademodule then
            -- 保存原始函数
            local old_onactivatedfn = inst.components.upgrademodule.onactivatedfn
            local old_ondeactivatedfn = inst.components.upgrademodule.ondeactivatedfn

            -- 激活时更新防水效果
            inst.components.upgrademodule.onactivatedfn = function(inst, wx, ...)
                if old_onactivatedfn then
                    old_onactivatedfn(inst, wx, ...)
                end
                if wx then
                    UpdateHeatWaterproof(wx)
                end
            end
            -- 卸载时更新防水效果
            inst.components.upgrademodule.ondeactivatedfn = function(inst, wx, ...)
                if old_ondeactivatedfn then
                    old_ondeactivatedfn(inst, wx, ...)
                end
                if wx then
                    -- 延迟更新，确保芯片已经卸载
                    wx:DoTaskInTime(0, UpdateHeatWaterproof)
                end
            end
        end
    end)
end)
-- 监听芯片升级事件（融合升级时）
AddPrefabPostInit("wx78", function(inst)
    if not TheWorld.ismastersim then return end
    -- 延迟执行，确保在其他Hook之后
    inst:DoTaskInTime(0.2, function(inst)
        if inst.components.upgrademoduleowner then
            -- 保存之前的UpdateActivatedModules
            local previous_UpdateActivatedModules = inst.components.upgrademoduleowner.UpdateActivatedModules
            inst.components.upgrademoduleowner.UpdateActivatedModules = function(self, ...)
                local result = previous_UpdateActivatedModules(self, ...)
                -- 更新防水效果
                UpdateHeatWaterproof(inst)
                return result
            end
        end
    end)
end)

--2025.11.28 YeFeng: 制冷电路效果新增防火效果
-- -- 更新防火效果的函数
-- local function UpdateColdFireproof(wx)
--     if not wx or not wx.components.health then return end
--     -- 检查是否有激活的制冷芯片
--     local has_cold_module = false
--     if wx.components.upgrademoduleowner then
--         for bartype, modules in pairs(wx.components.upgrademoduleowner.module_bars) do
--             for _, module in ipairs(modules) do
--                 if module and module.prefab == "wx78module_cold" and
--                     module.components.upgrademodule and module.components.upgrademodule.activated then
--                     has_cold_module = true
--                     break
--                 end
--             end
--         end
--     end
--     -- 根据是否有制冷芯片设置防火效果
--     if has_cold_module then
--         -- 设置火焰伤害倍率为0，完全免疫火焰
--         wx.components.health.externalfiredamagemultipliers:SetModifier(wx, 0, "wx78_cold_fireproof")
--         wx.wx78_cold_fireproof_active = true
--     else
--         -- 移除防火效果
--         if wx.wx78_cold_fireproof_active then
--             wx.components.health.externalfiredamagemultipliers:RemoveModifier(wx, "wx78_cold_fireproof")
--             wx.wx78_cold_fireproof_active = nil
--         end
--     end
-- end
-- -- Hook制冷电路的激活和卸载
-- AddPrefabPostInit("wx78module_cold", function(inst)
--     if not TheWorld.ismastersim then return end
--     inst:DoTaskInTime(0, function(inst)
--         if inst.components.upgrademodule then
--             local old_onactivatedfn = inst.components.upgrademodule.onactivatedfn
--             local old_ondeactivatedfn = inst.components.upgrademodule.ondeactivatedfn
--             -- 激活时：先调用原版函数（兼容《永不妥协》），再应用防火效果
--             inst.components.upgrademodule.onactivatedfn = function(inst, wx, ...)
--                 if old_onactivatedfn then
--                     old_onactivatedfn(inst, wx, ...)
--                 end
--                 if wx then
--                     UpdateColdFireproof(wx)
--                 end
--             end
--             -- 卸载时：先调用原版函数（兼容《永不妥协》），再移除防火效果
--             inst.components.upgrademodule.ondeactivatedfn = function(inst, wx, ...)
--                 if old_ondeactivatedfn then
--                     old_ondeactivatedfn(inst, wx, ...)
--                 end
--                 if wx then
--                     wx:DoTaskInTime(0, UpdateColdFireproof)
--                 end
--             end
--         end
--     end)
-- end)
-- -- 监听芯片升级事件（融合升级时）
-- AddPrefabPostInit("wx78", function(inst)
--     if not TheWorld.ismastersim then return end
--     -- 延迟执行，确保在其他Hook之后
--     inst:DoTaskInTime(0.25, function(inst)
--         if inst.components.upgrademoduleowner then
--             -- 保存之前的UpdateActivatedModules
--             local previous_UpdateActivatedModules = inst.components.upgrademoduleowner.UpdateActivatedModules
--             inst.components.upgrademoduleowner.UpdateActivatedModules = function(self, ...)
--                 local result = previous_UpdateActivatedModules(self, ...)
--                 -- 更新防火效果
--                 UpdateColdFireproof(inst)
--                 return result
--             end
--         end
--     end)
-- end)

--2025.11.28 YeFeng: 极限双元领域 - 热能电路+制冷电路组合效果
-- 检测是否同时装备Lv2热能和Lv2制冷电路
local function HasTemperatureBalance(wx)
    if not wx or not wx.components.upgrademoduleowner then return false end
    local has_heat_lv2 = false
    local has_cold_lv2 = false
    for bartype, modules in pairs(wx.components.upgrademoduleowner.module_bars) do
        for _, module in ipairs(modules) do
            if module and module.components.upgrademodule and module.components.upgrademodule.activated then
                -- 检查热能电路：必须是Lv2或以上
                if module.prefab == "wx78module_heat" and module.level2hm and module.level2hm:value() >= 2 then
                    has_heat_lv2 = true
                    -- 检查制冷电路：必须是Lv2或以上
                elseif module.prefab == "wx78module_cold" and module.level2hm and module.level2hm:value() >= 2 then
                    has_cold_lv2 = true
                end
            end
            if has_heat_lv2 and has_cold_lv2 then
                return true
            end
        end
    end
    return false
end

-- 更新极限双元领域效果
local function UpdateTemperatureBalance(wx)
    if not wx then return end
    local has_balance = HasTemperatureBalance(wx)
    if has_balance then
        -- 激活极限双元领域状态
        if not wx.temperature_balance_active2hm then
            wx.temperature_balance_active2hm = true
            -- 1. 添加温度恒定任务（每0.5秒修正到10度）
            if wx.temperature_balance_task2hm then
                wx.temperature_balance_task2hm:Cancel()
            end
            wx.temperature_balance_task2hm = wx:DoPeriodicTask(0.5, function(inst)
                if inst.components.temperature then
                    local target_temp = 10
                    local current_temp = inst.components.temperature.current
                    if math.abs(target_temp - current_temp) > 0.1 then
                        inst.components.temperature:SetTemperature(target_temp)
                    end
                end
            end)
            -- 2. 添加双向温度光环
            if not wx.components.heater then
                wx:AddComponent("heater")
            end
            wx.components.heater.heat = 80
            wx.components.heater.carriedheat = -80
            wx.components.heater:SetThermics(true, true)
            -- 播放特殊台词
            if wx.components.talker then
                wx.components.talker:Say(TUNING.isCh2hm and "极限功率达成，进入极限双元领域!" or
                    "EXTREME POWER ACHIEVED, ENTERING EXTREME BINARY DOMAIN!")
            end
        end
    else
        -- 移除极限双元领域状态
        if wx.temperature_balance_active2hm then
            wx.temperature_balance_active2hm = nil
            if wx.temperature_balance_task2hm then
                wx.temperature_balance_task2hm:Cancel()
                wx.temperature_balance_task2hm = nil
            end
            if wx.components.heater then
                wx.components.heater.heat = 0
                wx.components.heater.carriedheat = 0
            end
        end
    end
end
-- Hook WX78，在模块更新时检查极限双元领域
AddPrefabPostInit("wx78", function(inst)
    if not TheWorld.ismastersim then return end
    inst:DoTaskInTime(0.3, function(inst)
        if inst.components.upgrademoduleowner then
            local original_UpdateActivatedModules = inst.components.upgrademoduleowner.UpdateActivatedModules
            inst.components.upgrademoduleowner.UpdateActivatedModules = function(self, ...)
                local result = original_UpdateActivatedModules(self, ...)
                UpdateTemperatureBalance(inst)
                return result
            end
        end
    end)

    -- 2025.11.29 YeFeng: 修复穿越世界后电路效果失效的问题
    -- OnLoad时重新应用所有电路效果
    local old_OnLoad = inst.OnLoad
    inst.OnLoad = function(inst, data)
        if old_OnLoad then old_OnLoad(inst, data) end

        -- 延迟重新应用所有电路效果
        inst:DoTaskInTime(0.5, function(inst)
            if inst.components.upgrademoduleowner then
                -- 重新应用热能电路的防水效果
                UpdateHeatWaterproof(inst)
                -- 重新应用制冷电路的防火效果
                -- UpdateColdFireproof(inst)
                -- 重新应用极限双元领域效果
                UpdateTemperatureBalance(inst)
            end
        end)
    end
end)


--2025.11.23 YeFeng:芯片组合效果,豆增压电路（bee模块）+ 电气化电路（taser模块）=添加超载状态功能
-- 检查WX-78是否同时装备了bee模块和taser模块
local function CanEnterOverload(wx)
    if not wx or not wx.components.upgrademoduleowner then
        return false
    end
    local has_bee = false
    local has_taser = false
    for bartype, modules in pairs(wx.components.upgrademoduleowner.module_bars) do
        for _, module in ipairs(modules) do
            if module and module.components.upgrademodule and module.components.upgrademodule.activated then
                if module.prefab == "wx78module_bee" then
                    has_bee = true
                elseif module.prefab == "wx78module_taser" then
                    has_taser = true
                end
                -- 如果两个都找到了，可以提前返回
                if has_bee and has_taser then
                    return true
                end
            end
        end
    end
    return false
end

-- 超载状态效果更新（逐渐减弱）
local function UpdateOverloadEffects(wx)
    -- 检查是否还满足超载条件（同时装备bee和taser模块）
    if not CanEnterOverload(wx) then
        -- 不再满足条件，立即清除超载状态
        wx.overload_time2hm = 0
    end
    if not wx.overload_time2hm or wx.overload_time2hm <= 0 then
        -- 超载结束，清除所有效果
        if wx.overload_task2hm then
            wx.overload_task2hm:Cancel()
            wx.overload_task2hm = nil
        end
        if wx.overload_light2hm then
            wx.overload_light2hm:Enable(false)
        end
        if wx.components.locomotor then
            wx.components.locomotor:RemoveExternalSpeedMultiplier(wx, "wx78_overload2hm")
        end
        if wx.components.temperature then
            wx.components.temperature:RemoveModifier("wx78_overload2hm")
        end
        wx.overload_time2hm = nil
        wx:RemoveTag("wx78_overloaded2hm")
        return
    end
    -- 计算衰减系数（从1到0）
    local decay = wx.overload_time2hm / TUNING.TOTAL_DAY_TIME
    -- 更新移动速度（从50%逐渐降到0）
    if wx.components.locomotor then
        wx.components.locomotor:SetExternalSpeedMultiplier(wx, "wx78_overload2hm", 1 + 0.5 * decay)
    end
    -- 更新光照强度（从6格逐渐降到0）
    if wx.overload_light2hm then
        wx.overload_light2hm:SetRadius(6 * decay)
        wx.overload_light2hm:SetIntensity(0.8 * decay)
    end

    wx.overload_time2hm = wx.overload_time2hm - 1
end
-- 进入超载状态
local function EnterOverloadState(wx)
    if not CanEnterOverload(wx) then
        return
    end
    -- 添加超载标签
    wx:AddTag("wx78_overloaded2hm")
    -- 设置超载时长（约1天）
    wx.overload_time2hm = TUNING.TOTAL_DAY_TIME
    -- 恢复60点生命，损失33点理智
    if wx.components.health and not wx.components.health:IsDead() then
        wx.components.health:DoDelta(60)
    end
    if wx.components.sanity then
        wx.components.sanity:DoDelta(-33)
    end
    -- 添加光照组件
    if not wx.overload_light2hm then
        if not wx.Light then
            wx.entity:AddLight()
        end
        wx.overload_light2hm = wx.Light or wx.entity:AddLight()
        wx.overload_light2hm:SetFalloff(0.5)
        wx.overload_light2hm:SetColour(180 / 255, 195 / 255, 225 / 255)
    end
    wx.overload_light2hm:Enable(true)
    wx.overload_light2hm:SetRadius(6)
    wx.overload_light2hm:SetIntensity(0.8)
    -- 免疫寒冷（增加温度抗性，降低数值避免配合热能电路过热） -- 2026.2.15 YeFeng:从30降至15，修复插载热能电路超载后因模组降低过热阈值导致持续过热的问题
    if wx.components.temperature then
        wx.components.temperature:SetModifier("wx78_overload2hm", 15)
        -- wx.components.temperature:SetModifier("wx78_overload2hm", 30)
    end
    -- 设置移动速度加成（初始50%，随时间衰减）
    if wx.components.locomotor then
        wx.components.locomotor:SetExternalSpeedMultiplier(wx, "wx78_overload2hm", 1.5)
    end
    -- 启动更新任务（每秒更新一次）
    if wx.overload_task2hm then
        wx.overload_task2hm:Cancel()
    end
    wx.overload_task2hm = wx:DoPeriodicTask(1, UpdateOverloadEffects)
    -- 播放特效
    local fx = SpawnPrefab("electrichitsparks")
    if fx then
        fx.entity:SetParent(wx.entity)
    end
end
-- WX-78被闪电击中时触发超载
AddPrefabPostInit("wx78", function(inst)
    if not TheWorld.ismastersim then return end
    -- 延迟初始化，确保所有组件都加载完成
    inst:DoTaskInTime(0, function(inst)
        -- Hook playerlightningtarget 组件的 DoStrike 方法
        if inst.components.playerlightningtarget then
            local old_DoStrike = inst.components.playerlightningtarget.DoStrike
            inst.components.playerlightningtarget.DoStrike = function(self, ...)
                local result = old_DoStrike(self, ...)
                -- 在原版闪电处理后，检查是否同时装备bee和taser模块并触发超载
                if CanEnterOverload(inst) then
                    EnterOverloadState(inst)
                end
                return result
            end
        end
        -- 同时监听闪电击中事件（作为备用）
        inst:ListenForEvent("lightningstrike", function(wx, data)
            if CanEnterOverload(wx) then
                EnterOverloadState(wx)
            end
        end)
        -- 2025.11.24 YeFeng: 添加触摸女工发电机触发超载状态
        -- 为WX-78添加batteryuser组件（如果没有的话）
        if not inst.components.batteryuser then
            inst:AddComponent("batteryuser")
        end

        local oldonbatteryused = inst.components.batteryuser.onbatteryused
        inst.components.batteryuser.onbatteryused = function(wx, battery, ...)
            if battery and battery.wx78charge2hm == true then
                if CanEnterOverload(wx) then
                    EnterOverloadState(wx)
                    return true
                end
                return false , "CHARGE_FULL"
            end
            return oldonbatteryused and oldonbatteryused(wx, battery, ...)
        end
    end)
    -- 保存时清理任务
    local old_OnSave = inst.OnSave
    inst.OnSave = function(inst, data)
        if old_OnSave then old_OnSave(inst, data) end
        if inst.overload_time2hm and inst.overload_time2hm > 0 then
            data.overload_time2hm = inst.overload_time2hm
        end
    end
    -- 加载时恢复状态
    local old_OnLoad = inst.OnLoad
    inst.OnLoad = function(inst, data)
        if old_OnLoad then old_OnLoad(inst, data) end
        if data and data.overload_time2hm then
            inst.overload_time2hm = data.overload_time2hm
            EnterOverloadState(inst)
        end
    end
end)

-- 2025.11.24 YeFeng: 为发电机添加battery组件，使WX-78可以触摸发电机触发超载
-- 为低级发电机添加battery组件
AddPrefabPostInit("winona_battery_low", function(inst)
    if not TheWorld.ismastersim then
        return
    end
    -- 2025.11.25 YeFeng: 修改为强制覆盖模式
    -- 如果没有battery组件，则添加
    if not inst.components.battery then
        inst:AddComponent("battery")
    end
    -- 设置使用条件：发电机需要有足够的电
    local oldcanbeused = inst.components.battery.canbeused
    inst.components.battery.canbeused = function(battery, user, ...)
        local canuse, reason = oldcanbeused(battery, user, ...)
        if battery and canuse and user.prefab == "wx78" and not user.overload_time2hm and CanEnterOverload(user) then
            battery.wx78charge2hm = true
            return true
        else
            return canuse, reason
        end
    end
    -- 使用时的效果：消耗最大电量的50%
    local oldonused = inst.components.battery.onused
    inst.components.battery.onused = function(battery, user, ...)
        -- 消耗最大电量的50%
        if battery and battery.components.fueled and user.prefab == "wx78" and battery.wx78charge2hm then
            battery.wx78charge2hm = nil
            battery.components.fueled:DoDelta(-battery.components.fueled.maxfuel * 0.5, user)
            return
        end
        if oldonused then oldonused(battery, user, ...) end
    end
end)
-- 为高级发电机添加battery组件
AddPrefabPostInit("winona_battery_high", function(inst)
    if not TheWorld.ismastersim then
        return
    end
    -- 2025.11.25 YeFeng: 修改为强制覆盖模式
    -- 如果没有battery组件，则添加
    if not inst.components.battery then
        inst:AddComponent("battery")
    end
    -- 设置使用条件：发电机需要有足够的电
    local oldcanbeused = inst.components.battery.canbeused
    inst.components.battery.canbeused = function(battery, user, ...)
        local canuse, reason = oldcanbeused(battery, user, ...)
        if battery and canuse and user.prefab == "wx78" and not user.overload_time2hm and CanEnterOverload(user) then
            battery.wx78charge2hm = true
            return true
        else
            return canuse, reason
        end
    end
    -- 使用时的效果：消耗最大电量的25%
    local oldonused = inst.components.battery.onused
    inst.components.battery.onused = function(battery, user, ...)
        -- 消耗最大电量的25%
        if battery and battery.components.fueled and user.prefab == "wx78" and battery.wx78charge2hm then
            battery.wx78charge2hm = nil
            battery.components.fueled:DoDelta(-battery.components.fueled.maxfuel * 0.25, user)
            return
        end
        if oldonused then oldonused(battery, user, ...) end
    end
end)
-- 2025.11.24 YeFeng: 为避雷针添加battery组件，使WX-78可以触摸充能的避雷针触发超载
AddPrefabPostInit("lightning_rod", function(inst)
    if not TheWorld.ismastersim then
        return
    end
    -- 2025.11.25 YeFeng: 修改为强制覆盖模式
    -- 如果没有battery组件，则添加
    if not inst.components.battery then
        inst:AddComponent("battery")
    end
    -- 设置使用条件：避雷针需要被闪电击中过（有充能）
    local oldcanbeused = inst.components.battery.canbeused
    inst.components.battery.canbeused = function(battery, user, ...)
        local canuse, reason = oldcanbeused(battery, user, ...)
        if battery and canuse and user.prefab == "wx78" and not user.overload_time2hm and CanEnterOverload(user) then
            battery.wx78charge2hm = true
            return true
        else
            return canuse, reason
        end
    end
    local oldonused = inst.components.battery.onused
    inst.components.battery.onused = function(battery, user, ...)
        battery.wx78charge2hm = nil
        if oldonused then oldonused(battery, user, ...) end
    end
end)

-- 2025.11.26 YeFeng:饥饿芯片计数器管理（为负面反转系统提供芯片数量）
-- 装备/卸下饥饿芯片时更新 _hunger_chips 计数器
AddPrefabPostInit("wx78", function(inst)
    if not TheWorld.ismastersim then return end
    -- 延迟执行，确保芯片融合系统已经初始化
    inst:DoTaskInTime(0.1, function(inst)
        local owner = inst.components.upgrademoduleowner
        if not owner then return end
        local function UpdateHungerChipCount()
            local total_hunger_chips = 0
            for _, modules in pairs(owner.module_bars) do
                for _, module in ipairs(modules) do
                    if module and (module.prefab == "wx78module_maxhunger" or module.prefab == "wx78module_maxhunger1") then
                        -- 超级胃增益电路是 2 槽，普通胃增益电路是 1 槽。
                        -- 等级要按“等级 × 槽位”累计：两个超级电路 = 2 × 2 = 4 级。
                        local chip_level = (module.level2hm and module.level2hm:value()) or 1
                        local slots = module.components.upgrademodule and module.components.upgrademodule.slots or 1
                        total_hunger_chips = total_hunger_chips + chip_level * slots
                    end
                end
            end
            -- 覆盖计数（兼容《永不妥协》）
            inst._hunger_chips = total_hunger_chips
            inst._hunger_chips2hm = total_hunger_chips
        end
        local original_UpdateActivatedModules = owner.UpdateActivatedModules
        owner.UpdateActivatedModules = function(self, ...)
            -- 先调用原版函数（兼容《永不妥协》的activate逻辑）
            local result = original_UpdateActivatedModules(self, ...)
            UpdateHungerChipCount()
            return result
        end
        -- 读档时电路可能已经恢复，只补算等级，避免再次刷新激活状态。
        UpdateHungerChipCount()
    end)
end)
-- 2025.11.26 YeFeng:饥饿芯片负面反转系统（参考《永不妥协》模组）
-- 装备多个饥饿芯片可以递减食物负面效果，最高可反转为正面效果
-- 1芯片:负面减半 / 2芯片:减至25% / 3芯片:完全抵消 / 4芯片:反转为正面(不妥协模式下8格插槽，可以抵达4级)
local HUNGER_TABLES_2HM = { 0.5, 0.25, 0.00, -0.25 }
local function stats_negate_2hm(inst, health_delta, hunger_delta, sanity_delta)
    -- 获取正确的饥饿芯片数量
    -- 优先使用2hm保存的原始值（兼容《永不妥协》对_hunger_chips的调整）
    local raw_chips = inst._hunger_chips2hm or inst._hunger_chips
    if type(raw_chips) == "table" and raw_chips.value then raw_chips = raw_chips:value() end
    local hunger_chips = tonumber(raw_chips)
    if hunger_chips ~= nil then
        -- 芯片等级按等级累加：1 级芯片 +1，7 级芯片 +7。
        -- 1~3 级逐级降低负面，4 级及以上全部使用第 4 档反转收益。
        local chip_level = math.floor(hunger_chips)
        if chip_level >= 1 then
            local table_level = math.min(chip_level, 4)
            local negmult = HUNGER_TABLES_2HM[table_level]
            if negmult ~= nil then
                -- 只影响负面效果（< 0），正面效果不受影响
                if health_delta < 0 then
                    health_delta = health_delta * negmult
                end
                if sanity_delta < 0 then
                    sanity_delta = sanity_delta * negmult
                end
                if hunger_delta < 0 then
                    hunger_delta = hunger_delta * negmult
                end
            end
        end
    end
    return health_delta, hunger_delta, sanity_delta
end
AddPrefabPostInit("wx78", function(inst)
    if not TheWorld.ismastersim then return end
    -- 延迟执行确保其他模组已初始化完成
    inst:DoTaskInTime(0, function(inst)
        if inst.components.eater ~= nil then
            -- 保存已存在的 custom_stats_mod_fn（兼容《永不妥协》或其他模组）
            local _existing_custom_stats_mod_fn = inst.components.eater.custom_stats_mod_fn
            -- 使用包装模式：先调用已存在的函数，再调用我们的逻辑
            inst.components.eater.custom_stats_mod_fn = function(inst, health_delta, hunger_delta, sanity_delta, ...)
                -- 如果有其他模组的函数，先调用它
                if _existing_custom_stats_mod_fn then
                    health_delta, hunger_delta, sanity_delta = _existing_custom_stats_mod_fn(inst, health_delta,
                        hunger_delta, sanity_delta, ...)
                end
                -- 然后应用我们的负面反转逻辑
                return stats_negate_2hm(inst, health_delta, hunger_delta, sanity_delta)
            end
        end
    end)
end)

-- 2026.3.7 YeFeng: 扫描随机大小生物时，变大额外获得1~2个数据，变小减少1~2个数据
if GetModConfigData("Random Sized") then
    AddPrefabPostInit("wx78_scanner", function(inst)
        if not TheWorld.ismastersim then return end
        -- 扫描成功时缓存目标的myscale（因为StopAllScanning会清除scantarget）
        local _OnSuccessfulScan = inst.OnSuccessfulScan
        inst.OnSuccessfulScan = function(inst, ...)
            local target = inst.components.entitytracker:GetEntity("scantarget")
            if target and target.myscale then
                inst._scan_target_myscale2hm = target.myscale
            else
                inst._scan_target_myscale2hm = nil
            end
            return _OnSuccessfulScan(inst, ...)
        end
        -- 完全接管SpawnData，根据myscale调整产出数量
        inst.SpawnData = function(inst)
            local owner = inst.components.follower and inst.components.follower:GetLeader()
            if owner and owner.components.dataanalyzer then
                local amount = owner.components.dataanalyzer:SpendData(inst._scanned_id)
                -- 根据随机大小调整数据量
                if inst._scan_target_myscale2hm then
                    if inst._scan_target_myscale2hm > 1 then
                        amount = amount + math.random(1, 3)
                    elseif inst._scan_target_myscale2hm < 1 then
                        amount = math.max(1, amount - math.random(1, 2))
                    end
                    inst._scan_target_myscale2hm = nil
                end
                if amount > 0 then
                    local data = SpawnPrefab("scandata")
                    data.AnimState:PlayAnimation("fall")
                    data.AnimState:PushAnimation("idle")
                    local drop_pos = inst:GetPosition() + Vector3(math.random(), 0, math.random())
                    data.Transform:SetPosition(drop_pos:Get())
                    data.components.stackable:SetStackSize(amount)
                end
            end
            inst._scanned_id = nil
        end
    end)
end

if  GetModConfigData("WX-78 Drone Optimization") then
    -- 各种无人机距离增加，速度增加
    TUNING.SKILLS.WX78.SCOUTDRONE_RANGE = TUNING.SKILLS.WX78.SCOUTDRONE_RANGE * 3
    TUNING.SKILLS.WX78.DELIVERYDRONE_SPEED = TUNING.SKILLS.WX78.DELIVERYDRONE_SPEED * 3
    TUNING.SKILLS.WX78.SHADOWDRONE_HARVESTER_FINDITEM_RADIUS = TUNING.SKILLS.WX78.SHADOWDRONE_HARVESTER_FINDITEM_RADIUS * 2

    -- 破绽无人机可移动扫描
    TUNING.SKILLS.WX78.SHADOWDRONE_DEBUFFER_SCAN_RANGE = TUNING.SKILLS.WX78.SHADOWDRONE_DEBUFFER_SCAN_RANGE * 2
    TUNING.SKILLS.WX78.SHADOWDRONE_DEBUFFER_SCAN_RANGE_MAX = TUNING.SKILLS.WX78.SHADOWDRONE_DEBUFFER_SCAN_RANGE_MAX * 2

    local speed = TUNING.SKILLS.WX78.SHADOWDRONE_DEBUFFER_WALKSPEED
    local DEG_45 = 45 * DEGREES
    local WX78_ShadowDrone_BrainCommon = require("brains/wx78_shadowdrone_braincommon")
    local function GetScanTarget(inst)
        local target = inst:GetScanTarget()
        if target and not (target.components.health and target.components.health:IsDead()) then
            return target
        end
    end

    local function GetScanPos(inst)
        local target = GetScanTarget(inst)
        if target then
            local scandist--[[, maxdist]] = inst:CalcScanRange()
            local x1, y1, z1 = target.Transform:GetWorldPosition()
            local theta
            local offs = WX78_ShadowDrone_BrainCommon.GetFormationOffset(inst)
            if offs then
                theta = math.atan2(-offs.z, offs.x)
            else
                local x, y, z = inst.Transform:GetWorldPosition()
                if x == x1 and z == z1 then
                    theta = (inst.Transform:GetRotation() + 180) * DEGREES
                else
                    theta = math.atan2(z - z1, x - x1)
                end
            end
            --Snap to nearest 45 degrees, better matches 8-faced beams
            theta = math.floor(theta / DEG_45 + 0.5) * DEG_45
            return Vector3(x1 + scandist * math.cos(theta), 0, z1 - scandist * math.sin(theta))
        end
    end

    local function UpdatePositionToTarget(inst, dt)
        if not inst then return end
        
        local target_pos = GetScanPos(inst)
        if not target_pos then return end
        
        local current_pos = inst:GetPosition()
        local dx = target_pos.x - current_pos.x
        local dz = target_pos.z - current_pos.z
        local dist = math.sqrt(dx * dx + dz * dz)
        
        if dist < 0.1 then
            if inst.components.locomotor then
                inst.components.locomotor:Stop()
            end
            return
        end
        
        local dir_x = dx / dist
        local dir_z = dz / dist
        
        local move_dist = speed * dt
        
        if dist <= move_dist then
            inst.Transform:SetPosition(target_pos.x, target_pos.y, target_pos.z)
            if inst.components.locomotor then
                inst.components.locomotor:Stop()
            end
            return
        end
        
        local new_x = current_pos.x + dir_x * move_dist
        local new_z = current_pos.z + dir_z * move_dist
        
        inst.Transform:SetPosition(new_x, current_pos.y, new_z)
    end

    AddStategraphPostInit("wx78_shadowdrone_debuffer", function(sg)
        if sg and sg.states and sg.states.scanning and sg.states.scanning.onupdate then
            local oldonupdate = sg.states.scanning.onupdate
            sg.states.scanning.onupdate = function(inst, dt, ...)
                UpdatePositionToTarget(inst, dt)
                return oldonupdate(inst, dt, ...)
            end
        end
    end)

    -- 底盘附身兼容双线
    local wx78_common = require("prefabs/wx78_common")
    if wx78_common then
        local oldActivateSocketsIn = wx78_common.ActivateSocketsIn
        if oldActivateSocketsIn then
            wx78_common.ActivateSocketsIn = function(inst, socketposition, socketname, ...)
                oldActivateSocketsIn(inst, socketposition, socketname, ...)
                if inst and not inst:HasTag("player") and socketname and inst.doublesocket2hm then
                    local socketname_ = (socketname == SOCKETNAMES.SHADOW and SOCKETNAMES.GESTALTTRAPPER) or (socketname == SOCKETNAMES.GESTALTTRAPPER and SOCKETNAMES.SHADOW) or false
                    if inst.components.socketholder then
                        inst.components.socketholder:SetSocketPositionName(2, socketname_ == false and 0 or socketname_)
                    end
                end
            end
        end

        local oldDeactivateSocketsIn = wx78_common.DeactivateSocketsIn
        if oldDeactivateSocketsIn then
            wx78_common.DeactivateSocketsIn = function(inst, socketposition, socketname, ...)
                oldDeactivateSocketsIn(inst, socketposition, socketname, ...)
                if inst and not inst:HasTag("player") and inst.doublesocket2hm then
                    if inst.components.socketholder then
                        inst.components.socketholder:SetSocketPositionName(2, 0)
                    end
                end
            end
        end
    end

    AddComponentPostInit("socketholder", function(_self)
        if _self.CanTryToSocket then
            local oldCanTryToSocket = _self.CanTryToSocket
            _self.CanTryToSocket = function(self, item, ...)
                local result, reason, socketposition = oldCanTryToSocket(self, item, ...)
                if result and self.inst.doublesocket2hm then
                    local socketable = item.components.socketable
                    local socketname = socketable:GetSocketName()
                    local opposite_socket = (socketname == SOCKETNAMES.SHADOW and SOCKETNAMES.GESTALTTRAPPER)
                    or (socketname == SOCKETNAMES.GESTALTTRAPPER and SOCKETNAMES.SHADOW)
                    local opposite_positions = self:GetFirstFullSocketPosition(opposite_socket)
                    if opposite_positions then return false end
                    return result, reason, socketposition
                end
                return result, reason, socketposition
            end
        end

        if _self.SetMaxSockets then
            local oldSetMaxSockets = _self.SetMaxSockets
            _self.SetMaxSockets = function(self, maxsockets, ...)
                if self.inst and not self.inst:HasTag("player") and maxsockets == 1 then
                    self.inst.doublesocket2hm = true
                    maxsockets = 2
                end
                return oldSetMaxSockets(self, maxsockets, ...)
            end
        end
    end)
end